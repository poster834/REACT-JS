const path = require('path');
const HTMLWebpackPlugin = require('html-webpack-plugin');
const IS_DEV = NODE_ENV === 'development';
const IS_PROD = NODE_ENV === 'production';
const NODE_ENV = process.env.NODE_ENV;
function setupDevtool(params) {
    if (IS_DEV) return 'eval';
    if (IS_PROD) return false;
}
module.exports={
    entry:path.resolve(__dirname, 'src/index.jsx'),
    output:{
        path:path.resolve(__dirname, 'dist'),
        filename: 'index.js'
    },
    resolve:{
        extensions:['.js','.jsx','.tsx','.ts','.json']
    },
    mode: NODE_ENV ? NODE_ENV : 'development',
    
   
    module: {
        rules: [
            { test:/\.[tj]sx?$/,use:['ts-loader'] },
            
        ],
    },
    plugins: [
        new HTMLWebpackPlugin({template: path.resolve(__dirname, 'index.html') })
    ],
    devServer:{
        port: 3000,
        open: true,
        hot: true,
    },
    // devtool: setupDevtool()
};