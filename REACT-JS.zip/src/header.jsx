import * as React from "react";

export function Header(){
    return (
        <header>
            <h1>Reddit for our own</h1>
        </header>
    );

}