import * as React from "react";
import * as ReactDOM from "react-dom";

window.addEventListener('load',() => {
    ReactDOM.render(<header/>, document.getElementById("react_root"));
})
